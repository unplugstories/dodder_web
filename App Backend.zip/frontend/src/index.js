import express from 'express';

import middlewaresConfig from './config/middlewares';
import './config/db';
import {CustomerRoutes, AddressRoutes} from './modules'
const app = express();
var mongo=require('mongodb').MongoClient;
var url='mongodb://localhost:27017/reactapp-dev';

middlewaresConfig(app);

app.get('/', (req, res) => {
  res.send('Welcome');
});

app.get('/data', (req, res)=>{
  mongo.connect(url, (err, db)=>{
      var collection = db.collection('ninja');
      collection.find({}).toArray((x, abc)=>{
          res.send(abc);
      })
  })
})

app.post('/data', (req, res)=>{
  mongo.connect(url, (err, db)=>{
      var collection = db.collection('ninja');
      var reg = {
          fname: req.body.fname,
          lname: req.body.lname,
          email:req.body.email,
          paswrd:req.body.paswrd

      }
      collection.insert(reg, (x, abc)=>{
          res.send(abc);
      })
  })
})

app.post('/details', (req, res)=>{
  mongo.connect(url, (err, db)=>{
      var collection = db.collection('shipping');
      var detail = {
          streetname: req.body.streetname,
          aptno: req.body.aptno,
          city: req.body.city,
          postalcode:req.body.postalcode,
          state:req.body.state

      }
      collection.insert(detail, (x, abcd)=>{
          res.send(abcd);
      })
  })
})

app.get('/details/email', (req, res)=>{
  mongo.connect(url, (err, db)=>{
      var collection = db.collection('shipping');
      collection.find({}).toArray((x, abcd)=>{
          res.send(abcd);
      })
  })
})



app.use('/api/v1/customers', CustomerRoutes)
app.use('/api/v1/addresses', AddressRoutes)

app.listen(3000, err => {
  if (err) {
    console.error(err);
  } else {
    console.log(`Server listen on port 3000`);
  }
});
