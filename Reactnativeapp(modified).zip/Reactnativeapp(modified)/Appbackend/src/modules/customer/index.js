export { default as CustomerRoutes } from './customer.routes';
export * from './customer';
