import React, { Component } from 'react';
import {
  Image,
  StyleSheet,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Animated,
  Dimensions,
  View
  
} from 'react-native';
import { Box, Text, Button } from 'react-native-design-utility';
import { observer } from 'mobx-react/native';
import { Feather } from '@expo/vector-icons';

import { productImgs } from '../constants/images';
import { theme } from '../constants/theme';
import QtyHover from './QtyHover';

import { NavigationService } from '../api/NavigationService';
const ANIM_DURATION = 200;

const BoxAnimated = Animated.createAnimatedComponent(Box);

@observer
class ProductCard extends Component {
  state = {
    isHover: false,
    cardOpacity: new Animated.Value(1),
  };

  handlePlusPress = () => {
   
    this.setState({ isHover: true });
    if (this.props.product.cartQty === 0) {
      this.props.product.addToCart();
      alert('Product added to cart')
    }
    else if (this.props.product.cartQty >= 1) {
    
      alert('Product already in cart')
    }
  };

  handleInc = () => {
    this.props.product.incCartQty();
  };

  handleDec = () => {
    this.props.product.decCartQty();
  };

  handleClose = () => {
    this.fadeOut();
    this.setState({
      isHover: false,
    });
  };

  handleRemove = () => {
    this.handleClose();
    this.props.product.removeFromCart();
  };

  fadeIn = () => {
    Animated.timing(this.state.cardOpacity, {
      toValue: 0.4,
      duration: ANIM_DURATION,
    }).start();
  };

  fadeOut = () => {
    Animated.timing(this.state.cardOpacity, {
      toValue: 1,
      duration: ANIM_DURATION,
    }).start();
  };

  render() {
    const { isHover, cardOpacity, qtyCardOpacity } = this.state;
    const { product } = this.props;


    return (
      <Box bg="white" flex={1} w={360} p={10} >
        <TouchableWithoutFeedback onPress={this.handleClose}>
          <BoxAnimated o={cardOpacity}>
            <Box mb="sm" p={10}>
              <Image
                style={styles.img}
                resizeMode="contain"
                source={product.imageUrl}
              />
            </Box>
            <Box>
              <Text  size="lg" bold>
                INR{product.price} each
              </Text>
              <Text size="sm">
                {product.name}
              </Text>
              <Box style={styles.container}>
              <TouchableOpacity
            onPress={this.handlePlusPress}
           style={styles.cartbutton}
          >
           <Text left> Add To Cart</Text>
          </TouchableOpacity>
       
  
          <TouchableOpacity
        style={styles.cartbutton}
      
          >
           <Text> View Details</Text>
          </TouchableOpacity>
         
            </Box>
            </Box>
          </BoxAnimated>
        </TouchableWithoutFeedback>
      
         
        
        
      </Box>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    width: 300,
    height: 250,
  },
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  cartbutton:{
    borderWidth: 1,
    borderColor: theme.color.green,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    width: '48%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
  }
});

export default ProductCard;
