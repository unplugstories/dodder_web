import React, { Component } from 'react';
import { StatusBar, ScrollView, Image, TouchableOpacity, StyleSheet,TouchableHighlight, Button } from 'react-native';
import { Box, Text } from 'react-native-design-utility';
import { inject } from 'mobx-react/native';
import {
  MaterialIcons,
  EvilIcons,
  Ionicons,
  Feather,
} from '@expo/vector-icons';

import CloseBtn from '../commons/CloseBtn';
import ListColumn from '../commons/ListColumn';
import { theme } from '../constants/theme';
import {Input} from'../commons/Input';
import { ImagePicker, Permissions } from 'expo';
import { NavigationService } from '../api/NavigationService';
const baseIconStyle = {
  size: 25,
  color: theme.color.grey,
};

const LINKS = [
  {
    link: 'ChildProfile',
    title: 'ChildProfile',
    icon: <EvilIcons name="user" {...baseIconStyle} />,
  },
  {
    link: 'Settings',
    title: 'Your accounts settings',
    icon: <Feather name="settings" {...baseIconStyle} />,
  },
];

@inject('authStore')
class ProfileScreen extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'My Profile',
    headerLeft: (
      <CloseBtn left size={25} onPress={() => navigation.goBack(null)} />
    ),
  });
  constructor(props) {
    super(props);
    const { authStore } = this.props;
    this.state = {
       
       image: authStore.info.avatarUrl 
      }
  }
  

  _pickImage = async () => {
    const { authStore } = this.props;
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [4, 3],
    });
    console.log(result);
    this.setState({
      uri: {image:result.uri},

      
    });
    if (!result.cancelled) {
      this.setState({ image: result.uri });
    }
  };
  handleAddAddressPress = () => {
    this.props.navigation.navigate('Auth');
  };
 edit = () => {
    this.props.navigation.navigate('EditDetails');
  };
  render() {
    let { image } = this.state;
    const { authStore } = this.props;
    return (
      <Box f={1} bg="white">
        <StatusBar barStyle="dark-content" />
        <ScrollView>
        
        <Box  align="center" >
        
           
          <Box circle={120} avatar>
                <Image source={{ uri: image }} />
                
              </Box> 
      <ListColumn>
            
        <TouchableHighlight onPress={this._pickImage}>
        <ListColumn.Right>
        <Image source={require('../../assets/img/pencil.png')}/>
        </ListColumn.Right>
        </TouchableHighlight>
        
        </ListColumn>
              </Box>
             
             
            <Box align="center">
            <Text size="md" bold>
            Name : {authStore.info.firstName}
              </Text>
              
              <Text size="md" bold>
                Email : {authStore.info.email}
              </Text>
            
              <TouchableOpacity onPress={this.edit} style={styles.logBtn}>
            <Text>Edit Details</Text> 
            </TouchableOpacity>
              </Box>
        
          {LINKS.map(el => (
            <ListColumn link={el.link} key={el.title}>
              <ListColumn.Left>
                <Box dir="row" align="center">
                  <Box f={0.2}>{el.icon}</Box>

                  <Box f={1}>
                    <Text>{el.title}</Text>
                  </Box>
                </Box>
              </ListColumn.Left>
              <ListColumn.Right>
                <MaterialIcons name="keyboard-arrow-right" {...baseIconStyle} />
              </ListColumn.Right>
            </ListColumn>
          ))}

          <TouchableOpacity style={styles.logoutBtn} onPress={this.handleAddAddressPress}>
            <Text bold color="black">
              Log out
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </Box>
    );
  }
}

const styles = StyleSheet.create({
  logoutBtn: {
    borderWidth: 1,
    borderColor: theme.color.black,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    width: '50%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
  },
  logBtn: {
    borderWidth: 1,
    borderColor: theme.color.black,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    width: '30%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
  },
});

export default ProfileScreen;
