import React, { Component } from 'react';
import { StatusBar } from 'react-native';
import { Box, Text } from 'react-native-design-utility';
import PDFReader from 'rn-pdf-reader-js';
import CloseBtn from '../commons/CloseBtn';


class NoProfileScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: 'ProfileScreen',
        headerLeft: (
          <CloseBtn left size={25} onPress={() => navigation.navigate("Home")} />
        ),
      });
  state = {};
  render() {
    return (
      <Box f={1} center>
        <Text>You have not logged in yet</Text>
      </Box>
    );
  }
}

export default NoProfileScreen;
