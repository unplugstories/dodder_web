import React, { Component } from 'react';
import {
  StyleSheet,
  Dimensions,
  Button,
  View
} from 'react-native';
import { StackNavigator } from 'react-navigation';
import Pdf from 'react-native-pdf';

export default class pdfscreen extends Component {
    constructor(props) {
      super(props);
      this.pdf = null;
    }
  
    render() {
      let yourPDFURI = {uri:'./document.pdf', cache: true};
  
      return <View style={{flex: 1}}>
        <Pdf ref={(pdf)=>{this.pdf = pdf;}}
          source={yourPDFURI}
          style={{flex: 1}}
          onError={(error)=>{console.log(error);
          }} />
      </View>
    }
  }