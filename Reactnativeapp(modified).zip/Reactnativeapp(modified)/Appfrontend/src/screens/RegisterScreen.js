import React, { Component } from 'react'
import {Text, View, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, } from 'react-native'
import axios from 'axios';

import { theme } from '../constants/theme';

import CloseBtn from '../commons/CloseBtn';
import { NavigationService } from '../api/NavigationService';

class RegisterScreen extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'Register',
    headerLeft: (
      <CloseBtn left size={25} onPress={() => navigation.navigate("Auth")} />
    ),
  });
constructor(){
    super();
    this.state = {
    dataku: [],
  };
  }

klikPost(){
    var url = 'http://192.168.137.1:3000/data';
    axios.post(url, {
      fname: this.state.fname,
      lname: this.state.lname,
      email: this.state.email,
      paswrd: this.state.paswrd
    })
   

    if(this.state.fname!=null && this.state.lname!=null && this.state.email!=null && this.state.paswrd!=null )
    {
    NavigationService.navigate('LoginDirect');
    alert('Successfully Registered');
    }
    else
    {
      alert('Please fill in all the details');
    }

   
  };
  

render() {

    const dataMongo = this.state.dataku.map((item, index)=>{
        var arrayku = ['fname: ',item.fname,', lname: ', item.lname, ',email:',item.email,',paswrd:',item.paswrd,' th.'].join(' ');
        return <Text style={{fontSize:20,fontWeight:'bold'}} key={index}>{arrayku}</Text>;
      })

    return (
<View>
<View style={{flexDirection:'column', alignItems:'center'}}>

<TextInput
placeholder='First Name'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(fname) => this.setState({fname})}
value={this.state.fname}
/>

<TextInput
placeholder='Last Name'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(lname) => this.setState({lname})}
value={this.state.lname}
/>
<TextInput
placeholder='email'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(email) => this.setState({email})}
value={this.state.email}
/>

<TextInput
placeholder='password'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(paswrd) => this.setState({paswrd})}
value={this.state.paswrd}
/>
</View>

<View style={{flexDirection:'row', justifyContent:'center'}}>
<TouchableOpacity
style={{
    backgroundColor:'blue', borderRadius:10,
    flex:1, width:100, height:50, margin:20,
    flexDirection:'row', justifyContent:'center',
    alignItems:'center'
    }}
onPress={this.klikPost.bind(this)}
>
<Text style={styles.button}>
REGISTER
</Text>
</TouchableOpacity>

</View>

</View>
);
}
}

const styles = StyleSheet.create({
  buttonDisabled: {
    backgroundColor: theme.color.greyLight,
    borderColor: theme.color.greyLight,
  },
  button: {
    backgroundColor: theme.color.black,
  },
  deleteButton: {
    backgroundColor: theme.color.red,
    borderColor: theme.color.red,
    marginTop: 20,
  },
});

export default RegisterScreen;