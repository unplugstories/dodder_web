import React from 'react';
import {Box, Text} from 'react-native-design-utility';
import Icon from 'react-native-vector-icons/FontAwesome';

import { Avatar, Input } from 'react-native-elements';
import {StyleSheet,View, TouchableHighlight,Image, TouchableOpacity,AsyncStorage, ScrollView} from 'react-native';
import { theme } from '../constants/theme';
import DatePicker from 'react-native-datepicker'
import { ImagePicker, Permissions } from 'expo';

import RadioForm from 'react-native-radio-form';


const mockData = [
  {
      label: 'male',
      value: 'fi',
  },
  {
      label: 'female',
      value: 'se'
  },
];

export default class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hasCameraPermission: null,
      
            image: null,
            text: '',
            date:"",
            data:['Male','Female '],
            textInputData: '',
            getValue: '',
      

    };
    
  }
  
  takePicture = async () => {
    await Permissions.askAsync(Permissions.CAMERA);
    const { cancelled, uri } = await ImagePicker.launchCameraAsync({
      allowsEditing: false,
    });
    this.setState({ image: uri });
  };

  _pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [4, 3],
    });
    console.log(result);

    if (!result.cancelled) {
      this.setState({ image: result.uri });
    }
  };

  async componentWillMount() {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    this.setState({ hasCameraPermission: status === 'granted' });
  }

  _onSelect = ( item ) => {
    console.log(item);
  };

  login = (image, text, date, textInputData, data) => {
    alert('image: ' + image + ' text: ' + text + ' date: ' + date + 'textInputData: ' +textInputData + 'data: '+ data)
 }

  render() {
    let { image } = this.state; 
    
    return (
     
      <View  center  style={styles.container}>
        <ScrollView>
                  <Image source={{ uri: image }} style={styles.image} />
                  <View style={styles.row}>
                  <Button onPress={this._pickImage}><Text>Gallery</Text></Button>
                  <Button  onPress={this.takePicture}><Text>Take Picture</Text></Button>
                </View>
                <View style={styles.input}>
                
        </View>
        <View>
        <DatePicker
          style={{width: 320}}
          date={this.state.date} //initial date from state
          mode="date" //The enum of date, datetime and time
          placeholder="Enter Birthday Date"
          format="DD-MM-YYYY"
          minDate="01-01-2016"
          maxDate="01-01-2019"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          customStyles={{
            dateIcon: {
              position: 'absolute',
              left: 0,
              top: 6,
              marginLeft: 0
            },
            dateInput: {
              marginLeft: 0
            }
          }}
          onDateChange={(date) => {this.setState({date: date})}}
        />
       </View>
       <Input
            placeholder='Name'
            leftIcon={
           <Icon
           name='user'
           size={24}
          color='black'
         />
         }
         />
         <View>
         <Text f={1} center> Gender  </Text>
           <View f={1} center style={styles.radio}>
           
        <View style={{ marginVertical: 30 }} >
            <RadioForm
                style={{ width: 350 - 30 }}
                dataSource={mockData}
                itemShowKey="label"
                itemRealKey="value"
                circleSize={20}
                initial={1}
                formHorizontal={true}
                labelHorizontal={true}
                onPress={(item) => this._onSelect(item)}
                outerColor= '#000000'
                value={this.state.textInputData}
            />
            
          </View>
        </View>
         </View>
         <TouchableOpacity
               style = {styles.submitButton}
               onPress = {
                  () => this.login(this.state.image, this.state.date, this.state.text, this.state.textInputData, this.state.data )
               }>
               <Text style = {styles.submitButtonText}> Submit </Text>
            </TouchableOpacity>

          </ScrollView>
        </View>
       
        );
       
    }
}
const Button = ({ onPress, children }) => (
  <TouchableOpacity style={styles.button} onPress={onPress}>
    <Text style={styles.text}>{children}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  text: {
    fontSize: 21,
  },
  row: { flexDirection: 'row' },
  row1: { flexDirection: 'row' },
  inputBox: {
    width:300,
    backgroundColor:'rgba(255, 255,255,0.2)',
    borderRadius: 25,
    paddingHorizontal:16,
    fontSize:16,
    color:'#000000',
    marginVertical: 10
  },
  image: {
    top: 0.7,
    right: 0.10,
    width: 150,
    height: 150,
    borderRadius: 100,
    borderColor:"green",
    backgroundColor: '#a9a9a9',
    flex: 0,
    alignItems: 'center',
    position: 'relative',
    marginTop: 50,
    marginRight: 10
  },
  button: {
    margin: 15,
    backgroundColor: '#dddddd',
    borderWidth: 1,
    borderColor: theme.color.green,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '40%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
  },
  Input: {
    top: 0.2,
    flex: 0.7,
    width: 500,
  },
  Date: {
    top: 0.1,
    flex: 0.7,
    width: 300,
  },
  radio: {
    top: 0.1,
    flex: 0.7,
    width: 300,
    alignItems: 'center'
  },
  submitButton: {
    margin: 15,
    backgroundColor: '#dddddd',
    borderWidth: 1,
    borderColor: theme.color.green,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
 },
 submitButtonText:{
    color: 'black'
 },
  container: {
    flex: 0.9,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
