import React, { Component } from 'react';
import {
  StatusBar,
  ScrollView,
  StyleSheet,

} from 'react-native';
import { Box, Text } from 'react-native-design-utility';
import { inject } from 'mobx-react/native';
import Input from '../commons/Input';
import Button from '../commons/Button';
import { theme } from '../constants/theme';

import CloseBtn from '../commons/CloseBtn';
import {NavigationService} from '../api/NavigationService';
import { AuthStore } from '../stores/Auth';
@inject('authStore')
class EditDetails extends Component{
    static navigationOptions = ({ navigation }) => ({
        title: 'Edit Details',
        headerLeft: (
          <CloseBtn left size={25} onPress={() => navigation.navigate("Profile")} />
        ),
      });
      
      constructor(props) {
        super(props);
        const { authStore } = this.props;
        this.state = {
           
           name: authStore.info.firstName 
          }
      }
    save= () => {
        const { authStore } = this.props;
        this.setState({
            name:authStore.info.firstName
      
            
          });
          this.props.navigation.navigate('ProfileScreen');
      };
  render() {
    return (
        <Box f={1} bg="white" p="sm">
        <StatusBar barStyle="dark-content" />
        <ScrollView>
          <Box mb="sm">
            <Input 
              placeholder="Name"
        
              
            />

            
             
              
              <Box mb="sm">
                <Input placeholder="Email"  />
              </Box>

            
          </Box>

          <Button
         
            style={styles.button}
           onPress={this.save}
          >
           <Text>Save</Text> 
          </Button>

       
        </ScrollView>
      </Box>
    );
  }
}

const styles = StyleSheet.create({
    buttonDisabled: {
      backgroundColor: theme.color.greyLight,
      borderColor: theme.color.greyLight,
    },
    button: {
      backgroundColor: theme.color.green,
    },
    deleteButton: {
      backgroundColor: theme.color.red,
      borderColor: theme.color.red,
      marginTop: 20,
    },
  });
  
  export default EditDetails;