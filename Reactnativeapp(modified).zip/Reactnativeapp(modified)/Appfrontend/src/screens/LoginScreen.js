import React, { Component } from 'react';
import { Box, Text } from 'react-native-design-utility';
import { TouchableOpacity, Alert, Animated, StyleSheet , View } from 'react-native';
import { inject } from 'mobx-react/native';
import Button from '../commons/Button';
import OnboardingLogo from '../commons/OnboardingLogo';
import LoginButton from '../commons/LoginButton';
import { FacebookApi } from '../api/Facebook';
import { GoogleApi } from '../api/Google';
import theme from '../constants/theme';
import {NavigationService} from '../api/NavigationService';


const BoxAnimated = Animated.createAnimatedComponent(Box);


@inject('authStore')
class LoginScreen extends Component {
  state = {
    opacity: new Animated.Value(0),
    position: new Animated.Value(0),
  };

  componentDidMount() {
    Animated.parallel([this.positionAnim(), this.opacityAnim()]).start();
  }

  opacityAnim = () => {
    Animated.timing(this.state.opacity, {
      toValue: 1,
      duration: 200,
      delay: 100,
    }).start();
  };

  positionAnim = () => {
    Animated.timing(this.state.position, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  onGooglePress = async () => {
    try {
      const token = await GoogleApi.loginAsync();

      await this.props.authStore.login(token, 'GOOGLE');
    } catch (error) {
      console.log('error', error);
    }
  };

  onFacebookPress = async () => {
    try {
      const token = await FacebookApi.loginAsync();
      await this.props.authStore.login(token, 'FACEBOOK');
      console.log('token', token);
    } catch (error) {
      console.log('error', error);
    }
  };

  handleRegisterPress = () => {
    NavigationService.navigate('Register');
  };

  handleLoginDirectPress = () => {
    NavigationService.navigate('LoginDirect');
  };

  render() {
    const { opacity } = this.state;

    const logoTranslate = this.state.position.interpolate({
      inputRange: [0, 1],
      outputRange: [150, 0],
    });

    console.log('props', this.props);

    return (
      <Box f={1} center bg="white">
        <BoxAnimated
          f={1}
          style={{
            transform: [
              {
                translateY: logoTranslate,
              },
            ],
          }}
        >
          <Box f={1} center>
            <OnboardingLogo />
          </Box>
        </BoxAnimated>

        <BoxAnimated f={0.9} w='100%' style={{ opacity }}>
          <LoginButton onPress={this.onGooglePress} type="google">
            Continue with Google
          </LoginButton>
          <LoginButton onPress={this.onFacebookPress} type="facebook">
            Continue with Facebook
          </LoginButton>
        <View style={styles.container}>
          <Box f={1} w="40%">
          <Button style={styles.button} onPress={this.handleRegisterPress}>
          <Text bold color="white">
            Register
          </Text>
          </Button>
          </Box>

          <Box f={1} w="40%">
          <Button style={styles.button} onPress={this.handleLoginDirectPress}>
          <Text bold color="white">
            Login
          </Text>
          </Button>
          </Box>
          </View>

          
          <TouchableOpacity onPress={()=>NavigationService.navigate("Mains")}><Text style={styles.signupButton}> Skip and Continue</Text></TouchableOpacity>
        
          </BoxAnimated>

      </Box>
      
        





    );
  }
}

const styles = StyleSheet.create({
    button:{
    borderWidth: 1,
    borderColor: "green",
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    width: '50%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
    backgroundColor:"black",
  },
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  signupButton: {
    flexGrow: 1,
    alignItems:'flex-end',
    justifyContent :'center',
    paddingVertical:16,
    flexDirection:'row',
  	color:'#000000',
  	fontSize:16,
  	fontWeight:'500'
  }
});



export default LoginScreen;


