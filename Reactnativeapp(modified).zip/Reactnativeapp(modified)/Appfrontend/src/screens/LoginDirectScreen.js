import React, { Component } from 'react';
import {
  StatusBar,
  ScrollView,
  StyleSheet,
  TextInput
} from 'react-native';
import { Box, Text } from 'react-native-design-utility';
import Button from '../commons/Button';
import { theme } from '../constants/theme';
import CloseBtn from '../commons/CloseBtn';
import { NavigationService } from '../api/NavigationService';
import axios from 'axios';

class LoginDirectScreen extends Component{
    static navigationOptions = ({ navigation }) => ({
        title: 'Login',
        headerLeft: (
          <CloseBtn left size={25} onPress={() => navigation.navigate("Auth")} />
        ),
      });
      
      constructor(){
            super();
            this.state = {
            dataku: [],
          };
          }
        
    klikGet(){
      var url = 'http://192.168.137.1:3000/data';
      axios.get(url)
      .then((ambilData) => {
        this.setState({
          dataku: ambilData.data,
        }) 
      })
      const dataMongo = this.state.dataku.map((item, index)=>{
        var arrayku = ['fname: ',item.fname,', lname: ', item.lname, ', email: ', item.email,', paswrd: ', item.paswrd,' th.'].join(' ');
        if(this.state.email!=null && this.state.paswrd!=null ){
        if(this.state.email==item.email && this.state.paswrd==item.paswrd)
       {
         NavigationService.navigate('Home');
         alert('Loged In');
       }
       else
       {
         alert('Invalid Username/Password');
       }
      }
      else{
        alert('Please fill in all the details');

      }
      })

     
      
  
      
    };

   
    
  render() {
    return (
        <Box f={1} bg="white" p="sm">
        <StatusBar barStyle="dark-content" />
        <ScrollView>



<TextInput
placeholder='email'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(email) => this.setState({email})}
value={this.state.email}
/>

<TextInput
placeholder='password'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(paswrd) => this.setState({paswrd})}
value={this.state.paswrd}
/>

          <Button
         
            style={styles.button}
            onPress={this.klikGet.bind(this)}
          >
           <Text bold color="white">Login</Text> 
          </Button>

       
        </ScrollView>
      </Box>
    );
  }
}

const styles = StyleSheet.create({
    buttonDisabled: {
      backgroundColor: theme.color.greyLight,
      borderColor: theme.color.greyLight,
    },
    button: {
      backgroundColor: theme.color.black,
    },
    deleteButton: {
      backgroundColor: theme.color.red,
      borderColor: theme.color.red,
      marginTop: 20,
    },
  });
  
  export default LoginDirectScreen;