import { Facebook, Constants } from 'expo';

const permissions = ['public_profile', 'email', 'user_gender'];

const loginAsync = async () => {
  try {
    const { type, token } = await Facebook.logInWithReadPermissionsAsync(
      '394229294688139',
      { permissions },
    );

    if (type === 'success') {
      return Promise.resolve(token);
    }

    return Promise.reject('No success');
  } catch (error) {
    return Promise.reject(error);
  }
};

export const FacebookApi = {
  loginAsync,
};
