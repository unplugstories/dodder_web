import { Google, Constants } from 'expo';

const scopes = ['profile', 'email'];

const loginAsync = async () => {
  try {
    const result = await Google.logInAsync({
      androidClientId: "245652154526-21v6mnn51njrfisboec0u21v9jrfmmnh.apps.googleusercontent.com",
      iosClientId: "245652154526-oou2jue8h33tm1k637uggto26oajhqb9.apps.googleusercontent.com",
      scopes,
    });

    if (result.type === 'success') {
      return Promise.resolve(result.accessToken);
    }

    return Promise.reject('No success');
  } catch (error) {
    return Promise.reject(error);
  }
};

export const GoogleApi = {
  loginAsync,
};
