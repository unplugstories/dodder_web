import React, { Component } from 'react';
import {
  StatusBar,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  TextInput
} from 'react-native';
import { Box, Text } from 'react-native-design-utility';
import { observer, inject } from 'mobx-react/native';
import { observable, action, computed } from 'mobx';
import get from 'lodash.get';
import axios from 'axios';
import CloseBtn from '../commons/CloseBtn';
import Input from '../commons/Input';
import Button from '../commons/Button';
import { theme } from '../constants/theme';
import { buildAddress } from '../utils/buildAddress';

@inject('authStore')
@observer
class AddressForm extends Component {
  constructor(){
        super();
        this.state = {
        dataku: [],
      };
      }
    
    
  @observable
  address = get(this.props, 'address', null);

  @observable
  isSaving = false;

  @computed
  get streetName() {
    return get(this.address, 'street', '');
  }

  @computed
  get city() {
    return get(this.address, 'city', '');
  }

  @computed
  get postalCode() {
    return get(this.address, 'postalCode', '');
  }

  @action.bound
  async saveAddress() {
    this.isSaving = true;
    try {
      const address = buildAddress(value);

      this.address = address;
      await this.props.save(this.address);
    } catch (error) {
      console.log('error', error);
    }
  }
  klikPost(){
    var url = 'http://192.168.137.1:3000/details';
    axios.post(url, {
      streetname: this.state.input1,
      aptno: this.state.input2,
      city: this.state.input3,
      postalcode: this.state.input4,
      state:this.state.input5
  
    })
   
    this.state.input1 = '';
    this.state.input2 = '';
    this.state.input3 = '';
    this.state.input4 = '';
    this.state.input5='';
    if(this.state.input1!=null || this.state.input2!=null || this.state.input3!=null || this.state.input4!=null|| this.state.input5!=null)
    {
    NavigationService.navigate('Addresses');
    alert('Successfully Added');
    }
    else
    {
      alert('Please fill in the fields');
    }

  };
  
  render() {
    const { editMode } = this.props;

    if (this.isSaving) {
      return (
        <Box f={1} bg="white" center>
          <ActivityIndicator color={theme.color.green} size="large" />
        </Box>
      );
    }

    return (
      <Box f={1} bg="white" p="sm">
        <StatusBar barStyle="dark-content" />
        <ScrollView>
          <Box mb="sm">
           
<TextInput
placeholder='streetname'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(input1) => this.setState({input1})}
value={this.state.input1}
/>

<TextInput
placeholder='apartment no'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(input2) => this.setState({input2})}
value={this.state.input2}
/>
<TextInput
placeholder='city'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(input3) => this.setState({input3})}
value={this.state.input3}
/>

<TextInput
placeholder='postalcode'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(input4) => this.setState({input4})}
value={this.state.input4}
/>
<TextInput
placeholder='state'
style={{height: 55, width: 350, fontSize: 15}}
onChangeText={(input5) => this.setState({input5})}
value={this.state.input5}
/>
          </Box>

          <Button
            
            style={styles.button}
            onPress={this.klikPost.bind(this)}
          >
            <Text bold color="white">
              {editMode ? 'Edit' : 'Save'}
            </Text>
          </Button>

          {editMode && (
            <Button
              disabled={!this.address}
              disabledStyle={styles.buttonDisabled}
              style={styles.deleteButton}
              onPress={this.props.deleteAddress}
            >
              <Text bold color="white">
                Delete
              </Text>
            </Button>
          )}
        </ScrollView>
      </Box>
    );
  }
}

const styles = StyleSheet.create({
  buttonDisabled: {
    backgroundColor: theme.color.greyLight,
    borderColor: theme.color.greyLight,
  },
  button: {
    backgroundColor: theme.color.green,
  },
  deleteButton: {
    backgroundColor: theme.color.red,
    borderColor: theme.color.red,
    marginTop: 20,
  },
});

export default AddressForm;
