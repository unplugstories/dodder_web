import {
  createStackNavigator,
  createSwitchNavigator,
  createBottomTabNavigator,
} from 'react-navigation';
import React, { Component } from 'react';

import { NavigationService } from '../api/NavigationService';
import { theme } from '../constants/theme';
import TabBar from '../components/TabBar';
import ShoppingCartIcon from '../components/ShoppingCartIcon';
import { RegisterScreen} from '../screens/RegisterScreen';


const primaryHeader = {
  headerStyle: {
    backgroundColor: theme.color.grey,
  },
  headerTintColor: theme.color.white,
  headerTitleStyle: {
    fontWeight: '400',
  },
};

const AuthNavigator = createStackNavigator(
  {
    Login: {
      getScreen: () => require('./LoginScreen').default,
    },
  },
  
  {
    navigationOptions: {
      header: null,
    },
  },
);

const ShoppingCartNavigator = createStackNavigator({
  ShoppingCart: {
    getScreen: () => require('./ShoppingCartScreen').default,
    navigationOptions: {
      headerStyle: {
        backgroundColor: theme.color.white,
      },
    },
  },
});

const ProfileStack = createStackNavigator(
  {
    Profile: {
      getScreen: () => require('./ProfileScreen').default,
    },
    Settings: {
      getScreen: () => require('./SettingsScreen').default,
    },
    ChildProfile: {
      getScreen: () => require('./ChildProfileScreen').default,
    },
    Addresses: {
      getScreen: () => require('./AddressesScreen').default,
    },

   
    
   
  },
  {
    navigationOptions: {
      headerBackTitle: null,
      headerTintColor: theme.color.green,
      headerStyle: {
        backgroundColor: theme.color.white,
      },
      headerTitleStyle: {
        color: theme.color.black,
      },
    },
  },
);

const ProfileStacks = createStackNavigator(
  {
    Profile: {
      getScreen: () => require('./NoProfileScreen').default,
    },
    

   
  },
  {
    navigationOptions: {
      headerBackTitle: null,
      headerTintColor: theme.color.green,
      headerStyle: {
        backgroundColor: theme.color.white,
      },
      headerTitleStyle: {
        color: theme.color.black,
      },
    },
  },
);

const AddressFormStack = createStackNavigator(
  {
    AddressForm: {
      getScreen: () => require('./CreateAddressScreen').default,
    },
    EditAddress: {
      getScreen: () => require('./EditAddressScreen').default,
    },
    AutocompleteAddress: {
      getScreen: () => require('./AutocompleteAddressScreen').default,
    },
    EditDetails: {
      getScreen: () => require('./EditDetails').default,
    },
  },
  {
    navigationOptions: {
      headerBackTitle: null,
      headerTintColor: theme.color.green,
      headerStyle: {
        backgroundColor: theme.color.white,
      },
      headerTitleStyle: {
        color: theme.color.black,
      },
    },
  },
);
const LoginStack=createStackNavigator(
  {
  Register: {
    getScreen: () => require('./RegisterScreen').default,
  },
  
  LoginDirect: {
  getScreen: () => require('./LoginDirectScreen').default,
  },
}
);
const HomeStack = createStackNavigator(
  {
    Home: {
      getScreen: () => require('./HomeScreen').default,
    },
   
    Category: {
      getScreen: () => require('./CategoryScreen').default,
    },
  

    ShoppingCart: {
      screen: ShoppingCartNavigator,
      navigationOptions: {
        header: null,
      },
    },
  },
  {
    navigationOptions: { ...primaryHeader, headerRight: <ShoppingCartIcon /> },
  },
);
const HomeStacks = createStackNavigator(
  {
    Home: {
      getScreen: () => require('./HomeScreens').default,
    },
   
    Category: {
      getScreen: () => require('./CategoryScreen').default,
    },
 
  

    ShoppingCart: {
      screen: ShoppingCartNavigator,
      navigationOptions: {
        header: null,
      },
    },
  },
  {
    navigationOptions: { ...primaryHeader, headerRight: <ShoppingCartIcon /> },
  },
);

HomeStacks.navigationOptions = ({ navigation }) => {
  let tabBarVisible = true;

  console.log('navigation', navigation);

  if (
    NavigationService.getCurrentRouteName(navigation.state) === 'ShoppingCart'
  ) {
    tabBarVisible = false;
  }

  return {
    tabBarVisible,
  };
};

HomeStack.navigationOptions = ({ navigation }) => {
  let tabBarVisible = true;

  console.log('navigation', navigation);

  if (
    NavigationService.getCurrentRouteName(navigation.state) === 'ShoppingCart'
  ) {
    tabBarVisible = false;
  }

  return {
    tabBarVisible,
  };
};

const TabNavigator = createBottomTabNavigator(
  {
    Home: HomeStack,
    Profile: ProfileStack,
  },
  {
    tabBarComponent: props => <TabBar {...props} />,
  },
);
const TabNavigators = createBottomTabNavigator(
  {
 
    Home:HomeStacks,
    Profile:ProfileStacks,
    
  },
  {
    tabBarComponent: props => <TabBar {...props} />,
  },
);
const MainNavigator = createStackNavigator(
  {
    Tab: TabNavigator,
    Login:LoginStack,
    AddressForm: AddressFormStack,
  },
  {
    mode: 'modal',
    navigationOptions: {
      header: null,
    },
  },
);
const MainNavigators = createStackNavigator(
  {
    Tab: TabNavigators,
    Login:LoginStack,
    
  },
  {
    mode: 'modal',
    navigationOptions: {
      header: null,
    },
  },
);
const AppNavigator = createSwitchNavigator(
  {
    Splash: {
      getScreen: () => require('./SplashScreen').default,
    },
    Auth: AuthNavigator,
    Main: MainNavigator,
    Mains:MainNavigators,
  },
  {
    initialRouteName: 'Splash',
  },
);

class Navigation extends Component {
  state = {};
  render() {
    return (
      <AppNavigator ref={r => NavigationService.setTopLevelNavigator(r)} />
    );
  }
}

export default Navigation;
