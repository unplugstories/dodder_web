import React from 'react';
import {Box, Text} from 'react-native-design-utility';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Avatar, Input } from 'react-native-elements';
import {StyleSheet,View,ScrollView, TouchableHighlight,Image, TouchableOpacity,AsyncStorage,TextInput} from 'react-native';
import Button from '../commons/Button';
import DatePicker from 'react-native-datepicker'
import { ImagePicker, Permissions } from 'expo';
import { black } from 'ansi-colors';
import RadioForm from 'react-native-radio-form';
import axios from 'axios';

const mockData = [
  {
      label: 'male',
      value: 'fi',
  },
  {
      label: 'female',
      value: 'se'
  },
];

export default class App extends React.Component {
  constructor(){
        super();
        this.state = {
        dataku: [],
      };
      }
  
  takePicture = async () => {
    await Permissions.askAsync(Permissions.CAMERA);
    const { cancelled, uri } = await ImagePicker.launchCameraAsync({
      allowsEditing: false,
    });
    this.setState({ image: uri });
  };

  _pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [4, 3],
    });
    console.log(result);

    if (!result.cancelled) {
      this.setState({ image: result.uri });
    }
  };

  klikPost(){
    var url = 'http://192.168.137.1:3000/data';
    axios.post(url, {
      name: this.state.input1,
      nickname: this.state.input2,
      date: this.state.input3,
      radio: this.state.input4
    })
   

    if(this.state.input1!=null && this.state.input2!=null && this.state.input3!=null && this.state.input4!=null )
    {
    
      alert('Successfully ');
    }
    else
    {
      alert('Please fill in all the details');
    }

   
  };
  

  async componentWillMount() {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    this.setState({ hasCameraPermission: status === 'granted' });
  }

  _onSelect = ( item ) => {
    console.log(item);
  };
  
  


  render() {

    const dataMongo = this.state.dataku.map((item, index)=>{
      var arrayku = ['Name: ',item.name,', Nickname: ', item.nickname, ',date:',item.date,',radio:',item.radio,' th.'].join(' ');
      return <Text style={{fontSize:20,fontWeight:'bold'}} key={index}>{arrayku}</Text>;
    })

    let { image } = this.state;  
    return (
     <ScrollView>
      <Box f={0.5}center>
                  <Box  style={styles.circle}>
                   {image &&
                  <Image source={{ uri: image }} style={styles.circle} />}
                  </Box>

                  <Box  style={styles.contain}>
                  <Button style={styles.cartbutton} onPress={this._pickImage}> 
                <Text >Gallery</Text>
                </Button>
                <Button style={styles.cartbutton} onPress={this.takePicture}>
                <Text>Take Picture</Text>
                </Button>
                </Box>
                 
                 <Box>

                 </Box>

                <Box  f={0.10}  style= {styles.Input}>
                <Input
                  placeholder='Name'
                  value={this.state.input1}
                leftIcon={
                <Icon
               name='user'
           size={24}
          color='black'
         />
         }
         />

          <Input
                  placeholder='Nick Name '
                  value={this.state.input2}
                leftIcon={
                <Icon
               name='user'
           size={24}
          color='black'
         />
         }
         />
        </Box>    
         
        <Box f={0.7}  style={styles.Date}>
        
          <DatePicker
          style={{width: 320}}
          date={this.state.date} //initial date from state
          mode="date" //The enum of date, datetime and time
          placeholder="Enter Birthday Date"
          format="DD-MM-YYYY"
          minDate="01-01-2016"
          maxDate="01-01-2019"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          width="300"
          customStyles={{
            dateIcon: {
              position: 'absolute',
              left: 0,
              top: 6,
              marginLeft: 0
            },
            dateInput: {
              marginLeft: 0
            }
          }}
          onDateChange={(date) => {this.setState({date: date})}}
          value={this.state.input3}
          
        />
      </Box>
     
      <Box f={1}style={styles.radio}>
        
        <Box style={{ marginVertical: 10 }} >
            <RadioForm
                style={{ width: 350 - 30 }}
                dataSource={mockData}
                itemShowKey="label"
                itemRealKey="value"
                circleSize={20}
                initial={1}
                formHorizontal={true}
                labelHorizontal={true}
                onPress={(item) => this._onSelect(item)}
                outerColor= '#000000'
                value={this.state.input4}
            />
          </Box>
        </Box>
        
      </Box>
      <TouchableOpacity style={styles.cartbutton}
  onPress={this.klikPost.bind(this)}
>
<Text>
SUBMIT
</Text>
</TouchableOpacity>
              


               
                
                </ScrollView>
        );
       
    }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',

    marginTop: 50,
    padding:16
  },
  cartbutton:{
    borderWidth: 1,
    borderColor:'green',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    width: '42%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
  },
  
  buttons:{
    flex:0.7,
    borderWidth: 1,
    borderColor: 'green',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    width: '48%',
    alignSelf: 'center',
    height: 40,
    marginTop: 20,
  },
  contain: {
    top: 0.5,
    flex: 0.5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    alignItems: 'center',
    
  },
  circle: {
    top: 0.7,
    width: 150,
    height: 150,
    borderRadius: 100,
    borderColor:"green",
    backgroundColor: '#a9a9a9',
    flex: 0,
    
  },
  Input: {
    height: 150,
    top: 0.5,
    flex: 1,
    width: 300,
  },
 
  Date: {
    top: 0.1,
    flex: 0.10,
    width: 300,
  },
  radio: {
    top: 0.1,
    flex: 0.7,
    width: 300,
    alignItems: 'center'
  },
  MainContainer: {
    alignItems: 'center',
    flex: 1,
    margin: 10,
    marginTop: 60,
  },

  TextInputStyle: {
    textAlign: 'center',
    height: 40,
    width: 300,
    borderWidth: 1,
    borderColor: '#808000',
  },

  button: {
    width: '100%',
    height: 40,
    padding: 10,
    backgroundColor: '#808000',
    marginTop: 10,
  },

  buttonText: {
    color: '#fff',
    textAlign: 'center',
  },

  text: {
    fontSize: 20,
    textAlign: 'center',
  },
  
});