import React, { Component } from 'react';
import { StatusBar, FlatList, ScrollView } from 'react-native';
import { Box, Text } from 'react-native-design-utility';

import CategoryCard from '../components/CategoryCard';
import { theme } from '../constants/theme';
import DealCaroussel from '../components/DealCaroussel';
import ProfileBtn from '../commons/ProfileBtn';

  const categorie = [
    {
      id: 1,
      title: 'Buy Books',
      image: require('../../assets/img/plus.png'),
    },
  {
    id: 2,
    title: 'Bought Books\n Book1',
    image: require('../../assets/img/product-1.png'),
   
  },
  {
    id: 3,
    title: 'Bought Books\n Book2',
    image: require('../../assets/img/product-2.png'),
  },
  {
    id: 4,
    title: 'Bought Books\n Book3',
    image: require('../../assets/img/product-3.png'),
  },
  {
    id: 5,
    title: 'Bought Books\n Book4',
    image: require('../../assets/img/product-4.png'),
  },
  {
    id: 6,
    title: 'Bought Books\n Book5',
    image: require('../../assets/img/product-5.png'),
  }
 
 
];

const NUM_COLUMNS =2;

class HomeScreens extends Component {
  static navigationOptions = {
    title: 'Buy Books',
  };

  state = {};

  renderItem = ({ item, index }) => {
    let style = {};

    if (index % NUM_COLUMNS !== 0) {
      style.borderLeftWidth = 2;
      style.borderLeftColor = theme.color.greyLighter;
    }
    return (
      <Box w={1 / NUM_COLUMNS} bg="#ffffff" h={250} style={style}>
        <CategoryCard {...item} />
      </Box>
    );
  };

  keyExtractor = item => String(item.id);

  separator = () => <Box h={4} bg="greyLighter" />;

  render() {
    return (
      <Box f={1}>
     
        <StatusBar barStyle="dark-content" />
    
        <Box f={1}  h= "60%" bg="greyLighter" width={360} >
  <ScrollView>
         
          <FlatList 
            data={categorie}
            renderItem={this.renderItem}
            keyExtractor={this.keyExtractor}
            numColumns={NUM_COLUMNS}
            ItemSeparatorComponent={this.separator}
          />
                  </ScrollView>

        </Box>

      </Box>
    );
  }
}

export default HomeScreens;
